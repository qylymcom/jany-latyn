/**
 * Minimal Cyrillic → Jany-Latyn full form, written from WHITEPAPER.md §2, §15.1, §16
 * and Appendix A, only so that the rune stage can be tested here. The real engine
 * (packages/engine/src/convert.ts) replaces this in the integration.
 */
const CYR_VOWELS = new Set("аэеиоөуүыюяё".split(""));

const SIMPLE: Record<string, string> = {
  а: "a", б: "b", в: "v", г: "g", д: "d", ж: "j", з: "z", и: "i", й: "í", к: "k",
  л: "l", м: "m", н: "n", ң: "ŋ", о: "o", ө: "ö", п: "p", р: "r", с: "s", т: "t",
  у: "u", ү: "ü", ф: "f", х: "h", ц: "ts", ч: "ç", ш: "ş", щ: "ş", ы: "y", э: "e",
  ё: "ío", ю: "íu", я: "ía", ъ: "", ь: "",
};

function wordToJL(word: string): string {
  const lower = word.toLowerCase();
  const chars = [...lower];
  let out = "";
  for (let i = 0; i < chars.length; i++) {
    const ch = chars[i];
    const prev = i > 0 ? chars[i - 1] : null;
    if (ch === "е") {
      const iotated = prev === null || CYR_VOWELS.has(prev) || prev === "ъ" || prev === "ь";
      out += iotated ? "íe" : "e";
      continue;
    }
    out += SIMPLE[ch] ?? ch;
  }
  // case pattern of the source word
  const letters = [...word].filter((c) => /\p{L}/u.test(c));
  const allCaps = letters.length > 1 && letters.every((c) => c === c.toUpperCase() && c !== c.toLowerCase());
  if (allCaps) return out.toUpperCase();
  if (letters.length && letters[0] !== letters[0].toLowerCase()) return out.charAt(0).toUpperCase() + out.slice(1);
  return out;
}

export function cyrToJL(text: string): string {
  return text.replace(/[Ѐ-ӿ]+/gu, (w) => wordToJL(w));
}
