/**
 * Orhon-Enesaí keyboard layout on the physical positions of the Kyrgyz standard
 * Cyrillic layout (XKB symbols/kg "basic"). Runes have no case, so Shift is free
 * and carries the front-series form; AltGr (Option on macOS) carries the
 * syllabic signs, ligatures and remaining Yenisei variants.
 *
 *   level 1 = key            back series, vowels, neutral consonants
 *   level 2 = Shift          front series; on vowel keys, the k/t/č sign the chart pairs with that vowel
 *   level 3 = AltGr          syllabic signs / ligatures / first variant
 *   level 4 = AltGr+Shift    second variant
 *
 * Digits, period/comma and space keep their Kyrgyz-layout values.
 * null = key left unassigned at that level (emits nothing).
 */
export type Level = number | null;
export interface KeyDef { xkb: string; cyr: string; levels: [Level, Level, Level, Level] }

export const LAYOUT: KeyDef[] = [
  // number row extras
  { xkb: "AE11", cyr: "ө", levels: [0x10c07, 0x10c1c, null, null] },   // ö/ü | kö/kü
  { xkb: "AE12", cyr: "ң", levels: [0x10c2d, 0x10c2e, 0x10c2c, 0x10c2a] },
  // top row
  { xkb: "AD01", cyr: "й", levels: [0x10c16, 0x10c18, 0x10c17, 0x10c19] },
  { xkb: "AD02", cyr: "ц", levels: [0x205a, 0x2e30, null, null] },          // ⁚ word separator, ⸰ ring point
  { xkb: "AD03", cyr: "у", levels: [0x10c06, 0x10c47, null, null] },   // o/u | to/tu
  { xkb: "AD04", cyr: "к", levels: [0x10c34, 0x10c1a, 0x10c38, 0x10c1c] },   // q | k | qo/qu | kö/kü
  { xkb: "AD05", cyr: "е", levels: [0x10c05, 0x10c02, null, null] },   // e | ä
  { xkb: "AD06", cyr: "н", levels: [0x10c23, 0x10c24, 0x10c27, 0x10c25] },   // n¹ | n² | nt (chart) | Yenisei n²
  { xkb: "AD07", cyr: "г", levels: [0x10c0d, 0x10c0f, 0x10c0e, 0x10c10] },
  { xkb: "AD08", cyr: "ш", levels: [0x10c41, 0x10c42, 0x10c3f, 0x10c40] },
  { xkb: "AD09", cyr: "щ", levels: [0x10c35, 0x10c1b, 0x10c39, 0x10c37] },   // Yenisei k-forms key
  { xkb: "AD10", cyr: "з", levels: [0x10c15, 0x10c15, 0x10c14, null] },
  { xkb: "AD11", cyr: "х", levels: [0x10c1d, 0x10c1d, null, null] },
  { xkb: "AD12", cyr: "ъ", levels: [0x10c26, 0x10c2b, null, null] },        // Orkhon nt, Yenisei ny
  // home row
  { xkb: "AC01", cyr: "ф", levels: [0x10c1f, 0x10c1f, null, null] },
  { xkb: "AC02", cyr: "ы", levels: [0x10c03, 0x10c36, null, null] },   // ı | qı
  { xkb: "AC03", cyr: "в", levels: [0x10c0a, 0x10c0a, null, null] },
  { xkb: "AC04", cyr: "а", levels: [0x10c00, 0x10c00, 0x10c01, null] },
  { xkb: "AC05", cyr: "п", levels: [0x10c2f, 0x10c2f, 0x10c30, null] },      // p | — | op
  { xkb: "AC06", cyr: "р", levels: [0x10c3a, 0x10c3c, 0x10c3b, null] },
  { xkb: "AC07", cyr: "о", levels: [0x10c06, 0x10c38, null, null] },   // o/u | qo/qu
  { xkb: "AC08", cyr: "л", levels: [0x10c1e, 0x10c20, 0x10c21, 0x10c1f] },   // l¹ | l² | lt | Yenisei l¹
  { xkb: "AC09", cyr: "д", levels: [0x10c11, 0x10c13, 0x10c12, null] },
  { xkb: "AC10", cyr: "ж", levels: [0x10c33, 0x10c19, null, null] },
  { xkb: "AC11", cyr: "э", levels: [0x10c05, 0x10c05, null, null] },
  { xkb: "BKSL", cyr: "ү", levels: [0x10c08, 0x10c08, null, null] },
  // bottom row
  { xkb: "AB01", cyr: "я", levels: [null, null, null, null] },
  { xkb: "AB02", cyr: "ч", levels: [0x10c32, 0x10c31, 0x10c29, 0x10c28] },   // č | či | nč (chart) | Orkhon nč
  { xkb: "AB03", cyr: "с", levels: [0x10c3d, 0x10c3e, null, null] },
  { xkb: "AB04", cyr: "м", levels: [0x10c22, 0x10c22, null, null] },
  { xkb: "AB05", cyr: "и", levels: [0x10c04, 0x10c31, null, null] },   // i | či
  { xkb: "AB06", cyr: "т", levels: [0x10c44, 0x10c45, 0x10c47, 0x10c43] },   // t¹ | t² | to/tu | Orkhon t¹
  { xkb: "AB07", cyr: "ь", levels: [0x10c46, 0x10c48, null, null] },        // Yenisei t², baš
  { xkb: "AB08", cyr: "б", levels: [0x10c09, 0x10c0b, 0x10c0a, 0x10c0c] },
  { xkb: "AB09", cyr: "ю", levels: [null, null, null, null] },
];
