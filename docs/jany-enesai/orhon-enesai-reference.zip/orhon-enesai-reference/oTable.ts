/**
 * о/у resolution table for reverse conversion (runes → Jany-Latyn).
 * Key: previous nucleus | length | next nucleus | word-final, all visible in the runes.
 * Fitted on UD_Kyrgyz-KTMU train split (CC BY-SA 4.0); counts are o/u tokens in that split.
 * Unseen keys fall back to "o".
 */
export const O_TABLE: Record<string, "o" | "u"> = {
  "none|short|ou|nonfinal": "o", // o=892 u=302
  "ou|short|ou|nonfinal": "u", // o=228 u=530
  "ou|short|none|final": "u", // o=112 u=368
  "ou|short|none|nonfinal": "u", // o=126 u=345
  "ou|short|ay|nonfinal": "u", // o=11 u=382
  "none|short|ay|nonfinal": "u", // o=147 u=231
  "none|short|none|nonfinal": "o", // o=196 u=19
  "ay|long|none|final": "u", // o=56 u=156
  "none|short|front|nonfinal": "o", // o=113 u=54
  "ay|long|ay|nonfinal": "u", // o=0 u=154
  "front|short|ou|nonfinal": "o", // o=113 u=7
  "ay|short|ou|nonfinal": "o", // o=90 u=13
  "ay|long|ou|nonfinal": "u", // o=47 u=48
  "ou|short|front|nonfinal": "o", // o=61 u=29
  "ou|long|none|final": "u", // o=20 u=62
  "ay|short|none|nonfinal": "o", // o=54 u=10
  "ou|long|ou|nonfinal": "o", // o=40 u=21
  "ay|short|ay|nonfinal": "u", // o=10 u=47
  "none|long|ay|nonfinal": "o", // o=33 u=22
  "front|short|ay|nonfinal": "o", // o=29 u=21
  "none|long|ou|nonfinal": "o", // o=33 u=16
  "front|short|none|nonfinal": "o", // o=34 u=6
  "ou|long|ay|nonfinal": "u", // o=0 u=37
  "front|short|front|nonfinal": "o", // o=20 u=11
  "none|long|none|final": "u", // o=3 u=27
  "ay|short|front|nonfinal": "o", // o=24 u=4
  "none|long|front|nonfinal": "o", // o=14 u=0
  "front|short|none|final": "o", // o=12 u=1
  "none|long|none|nonfinal": "o", // o=8 u=1
  "ou|long|none|nonfinal": "o", // o=8 u=0
  "ay|short|none|final": "u", // o=3 u=4
  "ay|long|none|nonfinal": "u", // o=2 u=4
  "none|short|none|final": "u", // o=0 u=4
  "front|long|front|nonfinal": "o", // o=1 u=0
  "ay|long|front|nonfinal": "o", // o=1 u=0
  "front|long|none|final": "u", // o=0 u=1
};
