import { readFileSync } from "node:fs";
import { cyrToJL } from "./cyrToJL.ts";
import { toRunes, fromRunes, PRESETS, oContext, isVowel, type OContext } from "./orhonEnesai.ts";

const name = (s: string) => [...s].map((c) => "U+" + c.codePointAt(0)!.toString(16).toUpperCase()).join(" ");

// 1. front-end sanity against the whitepaper's own examples
const wp = [
  ["Жаңы жылдын биринчи күнү тоого чыгып, бийик чокудан шаарды көрдүк. Үйгө кайтканда чай ичип, эс алдык.",
   "Jaŋy jyldyn birinçi künü toogo çygyp, biíik çokudan şaardy kördük. Üígö kaítkanda çaí içip, es aldyk."],
  ["Адамдардын бир-бири менен алмашкан каттары, эл аралык иммуногистохимия же башка техникалык журналдарда чыккан изилдөө макалалар, элге белгилүү болгон ырлар жана чыгармалар — баары бир алфавитте жазылат.",
   "Adamdardyn bir-biri menen almaşkan kattary, el aralyk immunogistohimiía je başka tehnikalyk jurnaldarda çykkan izildöö makalalar, elge belgilüü bolgon yrlar jana çygarmalar — baary bir alfavitte jazylat."],
  ["аңкыгый жигит", "aŋkygyí jigit"],
  ["Европа объект семья коён аюу поэт аэропорт цирк борщ", "Íevropa obíekt semía koíon aíuu poet aeroport tsirk borş"],
];
let ok = true;
for (const [cyr, exp] of wp) {
  const got = cyrToJL(cyr);
  if (got !== exp) { ok = false; console.log("FRONT-END MISMATCH\n got:", got, "\n exp:", exp); }
}
console.log("front-end matches whitepaper examples:", ok);

// 2. worked examples in each preset
const examples = ["кыргыз", "Байыркы кыргыз алфавити", "Орхон-Энесай", "Манас", "тоо", "көл", "жол", "жер", "Теңир", "кол", "кул", "чай", "китеп", "күндөр", "колдор", "кулдар", "космос", "компьютер", "темиржол", "Бишкек", "Ысык-Көл", "алтын", "күнчыгыш", "Жалал-Абад", "мектеп", "алуу"];
for (const preset of Object.keys(PRESETS)) {
  console.log(`\n== ${preset}`);
  for (const w of examples) {
    const jl = cyrToJL(w);
    console.log(w.padEnd(26), jl.padEnd(26), toRunes(jl, PRESETS[preset]));
  }
}
console.log("\nsentence (default):", toRunes(cyrToJL(wp[0][0])));
console.log("sentence (inscription):", toRunes(cyrToJL(wp[0][0]), PRESETS.inscription));

// 3. corpus measurements on UD_Kyrgyz-KTMU (CC BY-SA 4.0)
const files = ["ky_ktmu-ud-train.conllu", "ky_ktmu-ud-test.conllu"].map((f) => readFileSync(`../data/UD_Kyrgyz-KTMU/${f}`, "utf8"));
const sentences = files.flatMap((t) => t.split("\n").filter((l) => l.startsWith("# text = ")).map((l) => l.slice(9)));
const tokens: string[] = [];
for (const s of sentences) for (const m of s.matchAll(/[Ѐ-ӿ]+(?:-[Ѐ-ӿ]+)*/gu)) tokens.push(m[0].toLowerCase());
const types = [...new Set(tokens)];
console.log(`\ncorpus: ${sentences.length} sentences, ${tokens.length} Cyrillic word tokens, ${types.length} types`);

const freq = new Map<string, number>(); for (const t of tokens) freq.set(t, (freq.get(t) ?? 0) + 1);

// 3a. word types that share a rune spelling with another word type (default preset)
function collisions(preset: string, key: (jl: string) => string) {
  const byRune = new Map<string, Set<string>>();
  for (const t of types) {
    const jl = cyrToJL(t);
    const r = key(jl);
    if (!byRune.has(r)) byRune.set(r, new Set());
    byRune.get(r)!.add(jl);
  }
  const groups = [...byRune.values()].filter((s) => s.size > 1);
  const collidingTypes = groups.reduce((n, g) => n + g.size, 0);
  let collidingTokens = 0;
  // tokens whose type collides
  const colliding = new Set(groups.flatMap((g) => [...g]));
  for (const t of tokens) if (colliding.has(cyrToJL(t))) collidingTokens++;
  return { groups, collidingTypes, collidingTokens };
}
for (const p of ["orhon-enesai", "unicode-strict", "inscription"]) {
  const c = collisions(p, (jl) => toRunes(jl, PRESETS[p]));
  console.log(`${p}: ${c.groups.length} rune spellings shared by ${c.collidingTypes} JL types (${(100 * c.collidingTypes / types.length).toFixed(1)}% of types, ${(100 * c.collidingTokens / tokens.length).toFixed(1)}% of tokens)`);
  console.log("   examples:", c.groups.slice(0, 12).map((g) => [...g].join("/")).join(", "));
}
// the о/у share of the default-preset collisions: fold o→u in JL and see how many collisions remain
{
  const base = collisions("orhon-enesai", (jl) => toRunes(jl, PRESETS["orhon-enesai"]));
  const nonOU = base.groups.filter((g) => new Set([...g].map((w) => w.replace(/o/g, "u"))).size > 1);
  console.log(`default preset collision groups not explained by о/у alone: ${nonOU.length}`, nonOU.slice(0, 10).map((g) => [...g].join("/")).join(", "));
}

// 3b. о/у reverse resolution accuracy by context (token-weighted), default glyph set
const counts: Record<OContext, { o: number; u: number }> = {
  "first": { o: 0, u: 0 }, "after-unrounded-back": { o: 0, u: 0 }, "after-rounded": { o: 0, u: 0 }, "after-front": { o: 0, u: 0 },
};
for (const t of tokens) {
  const letters = [...cyrToJL(t)];
  for (let k = 0; k < letters.length; k++) {
    const L = letters[k];
    if (L !== "o" && L !== "u") continue;
    if (k > 0 && letters[k - 1] === L) continue; // long vowel second half
    const ctx = oContext(letters, k);
    counts[ctx][L as "o" | "u"]++;
  }
}
console.log("\nо/у occurrences by context (tokens):", JSON.stringify(counts));

// 3c. word-level reverse accuracy with the default resolution
let exact = 0, total = 0, withO = 0, exactWithO = 0;
for (const t of tokens) {
  const jl = cyrToJL(t);
  const runes = toRunes(jl);
  const back = fromRunes(runes).jl;
  total++;
  const hasO = /[ou]/.test(jl);
  if (hasO) withO++;
  if (back === jl) { exact++; if (hasO) exactWithO++; }
}
console.log(`reverse (runes→JL), default resolution: ${(100 * exact / total).toFixed(1)}% of tokens exact; ${(100 * withO / total).toFixed(1)}% of tokens contain о/у, of which ${(100 * exactWithO / withO).toFixed(1)}% come back exact`);

// 3d. sanity: rune stage never leaves a JL letter behind and never mixes scripts inside a word
let leaks = 0;
for (const t of types) {
  for (const p of Object.keys(PRESETS)) {
    const r = toRunes(cyrToJL(t), PRESETS[p]);
    if (/[a-zçíŋöşüä]/u.test(r)) { leaks++; if (leaks < 5) console.log("leak", p, t, r); }
  }
}
console.log("JL letters left in rune output:", leaks);

// 3e. how often a word's consonants switch series inside the word (mixed harmony), default preset
let mixed = 0;
for (const t of types) {
  const jl = cyrToJL(t).replace(/-/g, "");
  const vs = [...jl].filter(isVowel);
  const back = vs.some((v) => "aouy".includes(v)), front = vs.some((v) => "eiöüä".includes(v));
  if (back && front) mixed++;
}
console.log(`word types with both back and front vowels (per-syllable harmony matters): ${mixed} (${(100 * mixed / types.length).toFixed(1)}%)`);
