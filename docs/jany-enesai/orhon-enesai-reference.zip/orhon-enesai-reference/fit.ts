import { readFileSync } from "node:fs";
import { cyrToJL } from "./cyrToJL.ts";
import { isVowel } from "./orhonEnesai.ts";
const load = (f: string) => readFileSync(`../data/UD_Kyrgyz-KTMU/${f}`, "utf8").split("\n").filter((l) => l.startsWith("# text = ")).map((l) => l.slice(9))
  .flatMap((s) => [...s.matchAll(/[Ѐ-ӿ]+(?:-[Ѐ-ӿ]+)*/gu)].map((m) => m[0].toLowerCase()));
const train = load("ky_ktmu-ud-train.conllu"), test = load("ky_ktmu-ud-test.conllu");
// features of an о/у nucleus at k (first half), from the rune-visible information only:
// prev nucleus class (from resolved left context: none / a-y / o-u / front), long?, next nucleus class
type Feat = string;
function nuclei(L: string[]) { const out: {k:number, v:string, long:boolean}[] = []; for (let k=0;k<L.length;k++){ if(!isVowel(L[k])) continue; if(k>0&&L[k-1]===L[k]) continue; out.push({k, v:L[k], long: L[k+1]===L[k]}); } return out; }
const cls = (v: string|undefined, resolved: boolean) => v===undefined ? "none" : (v==="a"||v==="y") ? "ay" : (v==="o"||v==="u") ? "ou" : "front";
// rune-visible: next nucleus o/u is just "ou"; previous uses resolved left context
function feats(L: string[]): {f: Feat, truth: string}[] {
  const N = nuclei(L); const res: {f:Feat, truth:string}[] = [];
  N.forEach((n, i) => { if (n.v!=="o"&&n.v!=="u") return;
    const prev = i>0 ? N[i-1].v : undefined; const next = i+1<N.length ? N[i+1].v : undefined;
    const end = n.long ? n.k+1 : n.k; const final = end === L.length-1;
    res.push({ f: `${cls(prev,true)}|${n.long?"long":"short"}|${cls(next,false)}|${final?"final":"nonfinal"}`, truth: n.v }); });
  return res;
}
function fitTable(tokens: string[]) { const c = new Map<Feat,{o:number,u:number}>(); for (const t of tokens) for (const {f,truth} of feats([...cyrToJL(t)])) { const e=c.get(f)??{o:0,u:0}; (e as any)[truth]++; c.set(f,e);} return c; }
function evaluate(tokens: string[], table: Map<Feat,{o:number,u:number}>, fallback: string) {
  let pos=0, posOK=0, words=0, wordsOK=0;
  for (const t of tokens) { const fs = feats([...cyrToJL(t)]); if (!fs.length) continue; words++; let all=true;
    for (const {f,truth} of fs) { pos++; const e = table.get(f); const guess = e ? (e.o>=e.u?"o":"u") : fallback; if (guess===truth) posOK++; else all=false; }
    if (all) wordsOK++; }
  return { positions: pos, posAcc: posOK/pos, words, wordAcc: wordsOK/words };
}
const tbl = fitTable(train);
console.log("table cells:", tbl.size);
console.log("fit on train, eval on train:", evaluate(train, tbl, "o"));
console.log("fit on train, eval on test :", evaluate(test, tbl, "o"));
// simple 3-default rule from before, for comparison
const simple = new Map<Feat,{o:number,u:number}>(); // emulate: first->o, after ay short->u, after ou->u, front->o
function evalSimple(tokens: string[]) { let pos=0, ok=0, words=0, wok=0; for (const t of tokens){ const L=[...cyrToJL(t)]; const N=nuclei(L); let any=false, all=true; N.forEach((n,i)=>{ if(n.v!=="o"&&n.v!=="u")return; any=true; pos++; const p=i>0?N[i-1].v:undefined; const g = p===undefined?"o":(p==="a"||p==="y")?"u":(p==="o"||p==="u")?"u":"o"; if(g===n.v) ok++; else all=false;}); if(any){words++; if(all) wok++;} } return {posAcc: ok/pos, wordAcc: wok/words}; }
console.log("simple rules, test:", evalSimple(test));
// print the learned table sorted by mass
console.log([...tbl.entries()].sort((a,b)=>(b[1].o+b[1].u)-(a[1].o+a[1].u)).map(([f,e])=>`${f} o=${e.o} u=${e.u} -> ${e.o>=e.u?"o":"u"}`).join("\n"));

// emit the table as TS data: key -> "o" | "u"
import { writeFileSync } from "node:fs";
const entries = [...tbl.entries()].sort((a,b)=>(b[1].o+b[1].u)-(a[1].o+a[1].u)).map(([f,e]) => `  "${f}": "${e.o>=e.u?"o":"u"}", // o=${e.o} u=${e.u}`);
writeFileSync("oTable.ts", `/**\n * о/у resolution table for reverse conversion (runes → Jany-Latyn).\n * Key: previous nucleus | length | next nucleus | word-final, all visible in the runes.\n * Fitted on UD_Kyrgyz-KTMU train split (CC BY-SA 4.0); counts are o/u tokens in that split.\n * Unseen keys fall back to "o".\n */\nexport const O_TABLE: Record<string, "o" | "u"> = {\n${entries.join("\n")}\n};\n`);
// overall token-level exactness on test (all tokens, not just о/у ones)
let all=0, ex=0; for (const t of test){ const fs=feats([...cyrToJL(t)]); all++; let ok=true; for(const {f,truth} of fs){ const e=tbl.get(f); const g=e?(e.o>=e.u?"o":"u"):"o"; if(g!==truth) ok=false;} if(ok) ex++; }
console.log("test: all tokens exact after о/у resolution:", (ex/all*100).toFixed(1)+"%", "tokens:", all);
// letters affected by the repurposed signs
const allTok = [...train, ...test]; const share = (re: RegExp) => (100*allTok.filter(t=>re.test(t)).length/allTok.length).toFixed(1)+"%";
console.log("tokens with ж:", share(/ж/), " ф:", share(/ф/), " х:", share(/х/), " в:", share(/в/), " any of ж ф х в:", share(/[жфхв]/));
