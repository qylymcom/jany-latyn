/**
 * The video chart, row by row, as read for this proposal: chart row number,
 * the Kyrgyz-Arabic value printed beside the rune, the Cyrillic it stands for
 * (via the second chart, Arabic ↔ Cyrillic ↔ Latin), and the Unicode character
 * the drawn rune corresponds to. Rows 46–50 are the five ligatures in the footer.
 */
export interface ChartRow {
  row: number; arabic: string; cyrillic: string; cp: number;
  /** "follows" = used for the value its Unicode name gives; "variant" = an Orkhon/Yenisei
   *  variant pressed into service for a distinction; "repurposed" = used for a different
   *  letter than its Unicode name; "not-emitted" = recorded but never produced by the converter. */
  unicodeFit: "follows" | "variant" | "repurposed" | "not-emitted";
  note?: string;
}

export const CHART: ChartRow[] = [
  { row: 1, arabic: "ا", cyrillic: "а", cp: 0x10c00, unicodeFit: "follows" },
  { row: 2, arabic: "ə", cyrillic: "(ä, not in Cyrillic)", cp: 0x10c02, unicodeFit: "follows", note: "compose-mode ä only" },
  { row: 3, arabic: "با", cyrillic: "б (back)", cp: 0x10c09, unicodeFit: "follows" },
  { row: 4, arabic: "به", cyrillic: "б (front)", cp: 0x10c0b, unicodeFit: "follows" },
  { row: 5, arabic: "جا", cyrillic: "ж (back)", cp: 0x10c33, unicodeFit: "repurposed", note: "Unicode: YENISEI EC (č)" },
  { row: 6, arabic: "جه", cyrillic: "ж (front)", cp: 0x10c19, unicodeFit: "repurposed", note: "Unicode: YENISEI AEY (front y); etymologically apt" },
  { row: 7, arabic: "چ", cyrillic: "ч", cp: 0x10c32, unicodeFit: "follows" },
  { row: 8, arabic: "چئ", cyrillic: "чи / ич", cp: 0x10c31, unicodeFit: "follows" },
  { row: 9, arabic: "دا", cyrillic: "д (back)", cp: 0x10c11, unicodeFit: "follows" },
  { row: 10, arabic: "ده", cyrillic: "д (front)", cp: 0x10c13, unicodeFit: "follows" },
  { row: 11, arabic: "ە", cyrillic: "э / е", cp: 0x10c05, unicodeFit: "follows" },
  { row: 12, arabic: "ف", cyrillic: "ф", cp: 0x10c1f, unicodeFit: "repurposed", note: "Unicode: YENISEI AL (back l)" },
  { row: 13, arabic: "عا", cyrillic: "г (back)", cp: 0x10c0d, unicodeFit: "follows" },
  { row: 14, arabic: "گه", cyrillic: "г (front)", cp: 0x10c0f, unicodeFit: "follows" },
  { row: 15, arabic: "ح", cyrillic: "х", cp: 0x10c1d, unicodeFit: "repurposed", note: "Unicode: YENISEI OEK (front k by ö/ü)" },
  { row: 16, arabic: "ئ", cyrillic: "и", cp: 0x10c04, unicodeFit: "variant", note: "Yenisei I, set against Orkhon I for ы" },
  { row: 17, arabic: "يا", cyrillic: "й (back)", cp: 0x10c16, unicodeFit: "follows" },
  { row: 18, arabic: "يه", cyrillic: "й (front)", cp: 0x10c18, unicodeFit: "follows" },
  { row: 19, arabic: "قا", cyrillic: "к (back, by а)", cp: 0x10c34, unicodeFit: "follows" },
  { row: 20, arabic: "كه", cyrillic: "к (front, by э/и)", cp: 0x10c1a, unicodeFit: "follows" },
  { row: 21, arabic: "قو", cyrillic: "к (back, by о/у)", cp: 0x10c38, unicodeFit: "follows" },
  { row: 22, arabic: "كو", cyrillic: "к (front, by ө/ү)", cp: 0x10c1c, unicodeFit: "follows" },
  { row: 23, arabic: "قى", cyrillic: "к (back, by ы)", cp: 0x10c36, unicodeFit: "follows" },
  { row: 24, arabic: "لا", cyrillic: "л (back)", cp: 0x10c1e, unicodeFit: "follows" },
  { row: 25, arabic: "له", cyrillic: "л (front)", cp: 0x10c20, unicodeFit: "follows" },
  { row: 26, arabic: "م", cyrillic: "м", cp: 0x10c22, unicodeFit: "follows" },
  { row: 27, arabic: "نا", cyrillic: "н (back)", cp: 0x10c23, unicodeFit: "follows" },
  { row: 28, arabic: "نه", cyrillic: "н (front)", cp: 0x10c24, unicodeFit: "follows" },
  { row: 29, arabic: "ڭ", cyrillic: "ң", cp: 0x10c2d, unicodeFit: "follows" },
  { row: 30, arabic: "ۇ/و", cyrillic: "о, у", cp: 0x10c06, unicodeFit: "follows", note: "the о/у merger" },
  { row: 31, arabic: "ۅ", cyrillic: "ө", cp: 0x10c07, unicodeFit: "variant", note: "Orkhon OE, set against Yenisei OE for ү" },
  { row: 32, arabic: "پ", cyrillic: "п", cp: 0x10c2f, unicodeFit: "follows" },
  { row: 33, arabic: "را", cyrillic: "р (back)", cp: 0x10c3a, unicodeFit: "follows" },
  { row: 34, arabic: "ره", cyrillic: "р (front)", cp: 0x10c3c, unicodeFit: "follows" },
  { row: 35, arabic: "سا", cyrillic: "с (back)", cp: 0x10c3d, unicodeFit: "follows" },
  { row: 36, arabic: "سه", cyrillic: "с (front)", cp: 0x10c3e, unicodeFit: "follows" },
  { row: 37, arabic: "ش", cyrillic: "ш", cp: 0x10c41, unicodeFit: "follows" },
  { row: 38, arabic: "تا", cyrillic: "т (back)", cp: 0x10c44, unicodeFit: "follows", note: "Yenisei AT" },
  { row: 39, arabic: "ته", cyrillic: "т (front)", cp: 0x10c45, unicodeFit: "follows" },
  { row: 40, arabic: "تو", cyrillic: "т (back, by о/у)", cp: 0x10c47, unicodeFit: "follows" },
  { row: 41, arabic: "ا", cyrillic: "а (second form)", cp: 0x10c01, unicodeFit: "not-emitted", note: "duplicate of row 1" },
  { row: 42, arabic: "ۉ", cyrillic: "ү", cp: 0x10c08, unicodeFit: "variant", note: "Yenisei OE" },
  { row: 43, arabic: "ۋ", cyrillic: "в", cp: 0x10c0a, unicodeFit: "repurposed", note: "Unicode: YENISEI AB (back b); mild" },
  { row: 44, arabic: "ى", cyrillic: "ы", cp: 0x10c03, unicodeFit: "variant", note: "Orkhon I" },
  { row: 45, arabic: "ز", cyrillic: "з", cp: 0x10c15, unicodeFit: "follows", note: "Yenisei EZ" },
  { row: 46, arabic: "لت", cyrillic: "лт", cp: 0x10c21, unicodeFit: "follows", note: "ligature; epigraphic only" },
  { row: 47, arabic: "نت", cyrillic: "нт", cp: 0x10c27, unicodeFit: "follows", note: "ligature; epigraphic only" },
  { row: 48, arabic: "نچ", cyrillic: "нч", cp: 0x10c29, unicodeFit: "follows", note: "ligature; epigraphic only" },
  { row: 49, arabic: "ڭ", cyrillic: "(ң, second form)", cp: 0x10c2a, unicodeFit: "not-emitted", note: "Unicode: ORKHON ENY (ny)" },
  { row: 50, arabic: "رت", cyrillic: "(рт)", cp: 0x10c48, unicodeFit: "not-emitted", note: "Unicode: ORKHON BASH" },
];
