import { readFileSync } from "node:fs";
import { cyrToJL } from "./cyrToJL.ts";
import { toRunes, fromRunes, PRESETS } from "./orhonEnesai.ts";
const load = (f: string) => readFileSync(`../data/UD_Kyrgyz-KTMU/${f}`, "utf8").split("\n").filter((l) => l.startsWith("# text = ")).map((l) => l.slice(9))
  .flatMap((s) => [...s.matchAll(/[Ѐ-ӿ]+(?:-[Ѐ-ӿ]+)*/gu)].map((m) => m[0].toLowerCase()));
const test = load("ky_ktmu-ud-test.conllu");
let noOU = 0, noOUexact = 0, all = 0, allExact = 0, withOU = 0, withOUexact = 0;
for (const t of test) {
  const jl = cyrToJL(t); const back = fromRunes(toRunes(jl)).jl; all++;
  const ex = back === jl;
  if (ex) allExact++;
  if (/[ou]/.test(jl)) { withOU++; if (ex) withOUexact++; } else { noOU++; if (ex) noOUexact++; }
}
console.log(`test split via integrated fromRunes: no-о/у ${noOUexact}/${noOU} (${(100*noOUexact/noOU).toFixed(1)}%), with-о/у ${(100*withOUexact/withOU).toFixed(1)}%, all ${(100*allExact/all).toFixed(1)}%`);
// golden consistency with current code
const g = JSON.parse(readFileSync("../out/orhon-enesai.golden.json", "utf8"));
let bad = 0;
for (const c of g.cases) for (const p of Object.keys(PRESETS)) if (toRunes(cyrToJL(c.cyrillic), PRESETS[p]) !== c.runes[p]) bad++;
console.log("golden mismatches vs current code:", bad);
// no unpaired surrogates in any golden output
const lone = /[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?<![\uD800-\uDBFF])[\uDC00-\uDFFF]/;
console.log("lone surrogates:", g.cases.some((c: any) => Object.values(c.runes).some((r: any) => lone.test(r))));
let pos = 0, posOK = 0;
for (const t of test) {
  const jl = [...cyrToJL(t)]; const back = [...fromRunes(toRunes(cyrToJL(t))).jl];
  for (let k = 0; k < jl.length; k++) {
    if (jl[k] !== "o" && jl[k] !== "u") continue;
    if (k > 0 && jl[k - 1] === jl[k]) continue; // count each long vowel once
    pos++; if (back[k] === jl[k]) posOK++;
  }
}
console.log(`integrated position accuracy on test: ${(100 * posOK / pos).toFixed(1)}% of ${pos}`);
