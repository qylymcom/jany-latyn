# Orhon-Enesaí reference kit

Reference prototype and fixtures for `docs/ORHON-ENESAI.md` and `docs/ORHON-ENESAI-AGENT-BRIEF.md`.
This is a specification aid, not production code: port it into `packages/engine/src/runes/` as the brief describes, then delete this folder.

| File | Purpose |
| :--- | :--- |
| `orhonEnesai.ts` | Rune stage: options, presets, inventory, governor, forward, epigraphic register, reverse |
| `oTable.ts` | о/у resolution table (36 contexts), fitted on the UD Kyrgyz-KTMU train split |
| `cyrToJL.ts` | Stand-in Cyrillic → Jany-Latyn front end, test use only; the engine replaces it |
| `keyboardLayout.ts` | The layout table; generate all keyboards from it |
| `chartReading.ts` | The video chart, row by row, with the Unicode match |
| `test.ts`, `fit.ts`, `fixtures.ts`, `verify.ts` | Scripts behind the figures and fixtures |
| `orhon-enesai.golden.json` | 44 golden cases, all three presets, with the default reverse result |
| `orhon-enesai.signs.json` | All 73 code points: chart rows, fit, emitting presets, keys |
| `chart-reading.png` | The chart reading as a table, for checking by eye against the video |
| `orhon-enesai-specimen.png` | The WHITEPAPER §2 passage in all three presets, rendered right to left |

## Running the scripts

Requires Bun (or Node 22+ with `--experimental-strip-types`). The corpus scripts expect the
UD Kyrgyz-KTMU treebank (CC BY-SA 4.0) at `../data/UD_Kyrgyz-KTMU` and write to `../out/`:

```sh
git clone --depth 1 https://github.com/UniversalDependencies/UD_Kyrgyz-KTMU ../data/UD_Kyrgyz-KTMU
mkdir -p ../out
bun run test.ts      # examples in every preset, corpus collision and reverse figures
bun run fit.ts       # refits oTable.ts on the train split, evaluates on the test split
bun run fixtures.ts  # keyboard coverage check, regenerates the golden and signs JSON
bun run verify.ts    # held-out reverse figures through the shipped fromRunes()
```

Do not vendor the treebank into the MIT engine package.
