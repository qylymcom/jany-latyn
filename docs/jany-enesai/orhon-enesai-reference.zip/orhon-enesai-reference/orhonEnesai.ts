/**
 * Orhon-Enesaí — reference prototype of the runic rendering stage.
 *
 * Input:  canonical Jany-Latyn full form (the engine's Cyrillic→Latin output with
 *         every testbed option at its Jany-Latyn default).
 * Output: Old Turkic script (Unicode block U+10C00–U+10C4F), in logical order.
 *
 * Dependency-free TypeScript. This is a specification aid for porting into
 * packages/engine, not production code: it has no streaming, no caching,
 * and only the error handling the tests need.
 */

import { O_TABLE } from "./oTable.ts";

// ───────────────────────────── options ─────────────────────────────

export type Register = "plene" | "epigraphic";

export interface RuneOptions {
  /** plene: every vowel written (default, reversible except о/у). epigraphic: one-way stylization. */
  register: Register;
  /** chart: ы/и and ө/ү told apart by Orkhon/Yenisei variants, э as 𐰅. historical: one letter per pair, as in the inscriptions. */
  vowels: "chart" | "historical";
  /** chart: ж → 𐰳 / 𐰙 as in the video chart. etymological: ж → the y-runes 𐰖 / 𐰘 (Old Turkic yol = Kyrgyz жол). */
  zhe: "chart" | "etymological";
  /** chart: ф 𐰟, х 𐰝, в 𐰊 as in the video chart. nativized: ф → p, х → k-series, в → b-series. */
  loanConsonants: "chart" | "nativized";
  /** chart: back т 𐱄 and з 𐰕 (Yenisei forms the chart uses). orkhon: 𐱃 and 𐰔. Also selects the Orkhon ENT/ENC ligatures. */
  variants: "chart" | "orkhon";
  /** single: ң → 𐰭 everywhere (chart). yenisei-pair: back 𐰬 / front 𐰮. */
  nasal: "single" | "yenisei-pair";
  /** Use the vowel-specific k/t/č signs 𐰸 𐰶 𐰜 𐱇 𐰱 (chart). Off: plain series signs only. */
  syllabicSigns: boolean;
  /** Word separator. space keeps ordinary spaces; two-dot writes U+205A between words. */
  separator: "space" | "two-dot";
}

export const PRESETS: Record<string, RuneOptions> = {
  /** The default: the video chart's assignments, written in full. */
  "orhon-enesai": {
    register: "plene", vowels: "chart", zhe: "chart", loanConsonants: "chart",
    variants: "chart", nasal: "single", syllabicSigns: true, separator: "space",
  },
  /** Every codepoint used for the value its Unicode name gives it. */
  "unicode-strict": {
    register: "plene", vowels: "chart", zhe: "etymological", loanConsonants: "nativized",
    variants: "chart", nasal: "single", syllabicSigns: true, separator: "space",
  },
  /** Closest to how the inscriptions look: historical vowels, abbreviated spelling, two-dot divider. */
  inscription: {
    register: "epigraphic", vowels: "historical", zhe: "etymological", loanConsonants: "nativized",
    variants: "orkhon", nasal: "single", syllabicSigns: true, separator: "two-dot",
  },
};

export const DEFAULT_OPTIONS: RuneOptions = PRESETS["orhon-enesai"];

// ───────────────────────────── inventory ─────────────────────────────

const R = (cp: number) => String.fromCodePoint(cp);

export const RUNE = {
  ORKHON_A: R(0x10c00), YENISEI_A: R(0x10c01), YENISEI_AE: R(0x10c02),
  ORKHON_I: R(0x10c03), YENISEI_I: R(0x10c04), YENISEI_E: R(0x10c05),
  ORKHON_O: R(0x10c06), ORKHON_OE: R(0x10c07), YENISEI_OE: R(0x10c08),
  ORKHON_AB: R(0x10c09), YENISEI_AB: R(0x10c0a), ORKHON_AEB: R(0x10c0b),
  ORKHON_AG: R(0x10c0d), ORKHON_AEG: R(0x10c0f),
  ORKHON_AD: R(0x10c11), ORKHON_AED: R(0x10c13),
  ORKHON_EZ: R(0x10c14), YENISEI_EZ: R(0x10c15),
  ORKHON_AY: R(0x10c16), ORKHON_AEY: R(0x10c18), YENISEI_AEY: R(0x10c19),
  ORKHON_AEK: R(0x10c1a), ORKHON_OEK: R(0x10c1c), YENISEI_OEK: R(0x10c1d),
  ORKHON_AL: R(0x10c1e), YENISEI_AL: R(0x10c1f), ORKHON_AEL: R(0x10c20),
  ORKHON_ELT: R(0x10c21), ORKHON_EM: R(0x10c22),
  ORKHON_AN: R(0x10c23), ORKHON_AEN: R(0x10c24),
  ORKHON_ENT: R(0x10c26), YENISEI_ENT: R(0x10c27),
  ORKHON_ENC: R(0x10c28), YENISEI_ENC: R(0x10c29),
  YENISEI_ANG: R(0x10c2c), ORKHON_ENG: R(0x10c2d), YENISEI_AENG: R(0x10c2e),
  ORKHON_EP: R(0x10c2f), ORKHON_IC: R(0x10c31), ORKHON_EC: R(0x10c32), YENISEI_EC: R(0x10c33),
  ORKHON_AQ: R(0x10c34), ORKHON_IQ: R(0x10c36), ORKHON_OQ: R(0x10c38),
  ORKHON_AR: R(0x10c3a), ORKHON_AER: R(0x10c3c),
  ORKHON_AS: R(0x10c3d), ORKHON_AES: R(0x10c3e),
  ORKHON_ESH: R(0x10c41),
  ORKHON_AT: R(0x10c43), YENISEI_AT: R(0x10c44), ORKHON_AET: R(0x10c45), ORKHON_OT: R(0x10c47),
} as const;

export const TWO_DOT = "⁚"; // ⁚ TWO DOT PUNCTUATION

// ───────────────────────────── letter classes ─────────────────────────────

const VOWELS = new Set(["a", "e", "i", "o", "u", "y", "ö", "ü", "ä"]);
const BACK_VOWELS = new Set(["a", "o", "u", "y"]);
const ROUNDED_BACK = new Set(["o", "u"]);
const ROUNDED_FRONT = new Set(["ö", "ü"]);
const LOW_VOWELS = new Set(["a", "e", "ä"]);

/** Canonical Jany-Latyn letters (plus compose-mode ä). Anything else passes through untouched. */
const JL_LETTERS = new Set("abçdefghiíjklmnŋoöprsştuüvyzä".split(""));

export const isVowel = (ch: string) => VOWELS.has(ch);

type Series = "back" | "front";

// ───────────────────────────── per-letter mapping ─────────────────────────────

function vowelRune(v: string, o: RuneOptions): string {
  if (o.vowels === "historical") {
    switch (v) {
      case "a": case "e": case "ä": return RUNE.ORKHON_A;
      case "y": case "i": return RUNE.ORKHON_I;
      case "o": case "u": return RUNE.ORKHON_O;
      case "ö": case "ü": return RUNE.ORKHON_OE;
    }
  }
  switch (v) {
    case "a": return RUNE.ORKHON_A;      // chart row 1
    case "e": return RUNE.YENISEI_E;     // chart row 11 (ە)
    case "ä": return RUNE.YENISEI_AE;    // chart row 2 (ə); compose-mode input only
    case "y": return RUNE.ORKHON_I;      // chart row 44 (ى = ы)
    case "i": return RUNE.YENISEI_I;     // chart row 16 (ئ = и)
    case "o": case "u": return RUNE.ORKHON_O; // chart row 30 (و/ۇ) — the о/у merger
    case "ö": return RUNE.ORKHON_OE;     // chart row 31 (ۅ)
    case "ü": return RUNE.YENISEI_OE;    // chart row 42 (ۉ)
  }
  throw new Error(`not a vowel: ${v}`);
}

/** The rune for consonant c whose syllable vowel is g (null when the word has no vowel). */
function consonantRune(c: string, g: string | null, o: RuneOptions): string {
  const s: Series = g === null || BACK_VOWELS.has(g) ? "back" : "front";
  const pick = (back: string, front: string) => (s === "back" ? back : front);

  // loan consonants first, since the nativized option re-routes them
  if (o.loanConsonants === "nativized") {
    if (c === "f") return RUNE.ORKHON_EP;
    if (c === "h") c = "k";
    if (c === "v") c = "b";
  }
  if (o.zhe === "etymological" && c === "j") c = "í";

  switch (c) {
    case "b": return pick(RUNE.ORKHON_AB, RUNE.ORKHON_AEB);
    case "d": return pick(RUNE.ORKHON_AD, RUNE.ORKHON_AED);
    case "g": return pick(RUNE.ORKHON_AG, RUNE.ORKHON_AEG);
    case "l": return pick(RUNE.ORKHON_AL, RUNE.ORKHON_AEL);
    case "n": return pick(RUNE.ORKHON_AN, RUNE.ORKHON_AEN);
    case "r": return pick(RUNE.ORKHON_AR, RUNE.ORKHON_AER);
    case "s": return pick(RUNE.ORKHON_AS, RUNE.ORKHON_AES);
    case "í": return pick(RUNE.ORKHON_AY, RUNE.ORKHON_AEY);
    case "j": return pick(RUNE.YENISEI_EC, RUNE.YENISEI_AEY); // chart rows 5, 6
    case "k":
      if (s === "back") {
        if (o.syllabicSigns && g !== null && ROUNDED_BACK.has(g)) return RUNE.ORKHON_OQ; // row 21 قو
        if (o.syllabicSigns && g === "y") return RUNE.ORKHON_IQ;                          // row 23 قى
        return RUNE.ORKHON_AQ;                                                             // row 19 قا
      }
      if (o.syllabicSigns && g !== null && ROUNDED_FRONT.has(g)) return RUNE.ORKHON_OEK;   // row 22 كو
      return RUNE.ORKHON_AEK;                                                              // row 20 كه
    case "t":
      if (s === "back") {
        if (o.syllabicSigns && g !== null && ROUNDED_BACK.has(g)) return RUNE.ORKHON_OT;   // row 40 تو
        return o.variants === "orkhon" ? RUNE.ORKHON_AT : RUNE.YENISEI_AT;                 // row 38 تا
      }
      return RUNE.ORKHON_AET;                                                              // row 39 ته
    case "ç":
      return o.syllabicSigns && g === "i" ? RUNE.ORKHON_IC : RUNE.ORKHON_EC;              // rows 8, 7
    case "ŋ":
      return o.nasal === "yenisei-pair" ? pick(RUNE.YENISEI_ANG, RUNE.YENISEI_AENG) : RUNE.ORKHON_ENG;
    case "m": return RUNE.ORKHON_EM;
    case "p": return RUNE.ORKHON_EP;
    case "ş": return RUNE.ORKHON_ESH;
    case "z": return o.variants === "orkhon" ? RUNE.ORKHON_EZ : RUNE.YENISEI_EZ;
    case "f": return RUNE.YENISEI_AL;   // chart row 12 — repurposed
    case "h": return RUNE.YENISEI_OEK;  // chart row 15 — repurposed
    case "v": return RUNE.YENISEI_AB;   // chart row 43
  }
  throw new Error(`no rune for consonant: ${c}`);
}

// ───────────────────────────── syllable governor ─────────────────────────────

/**
 * Index of the vowel that governs the consonant at k: the following vowel when
 * the consonant is the onset of its syllable (it directly precedes a vowel, or
 * belongs to a word-initial cluster); otherwise the preceding vowel. Kyrgyz
 * syllabification puts exactly one consonant in a medial onset (V.CV, VC.CV,
 * VCC.CV). Returns -1 for a word without vowels.
 */
export function governingVowelIndex(letters: string[], k: number): number {
  let p = -1, n = -1;
  for (let i = k - 1; i >= 0; i--) if (isVowel(letters[i])) { p = i; break; }
  for (let i = k + 1; i < letters.length; i++) if (isVowel(letters[i])) { n = i; break; }
  if (n !== -1 && (p === -1 || n === k + 1)) return n;
  if (p !== -1) return p;
  return -1;
}

// ───────────────────────────── word conversion ─────────────────────────────

interface Cell { letter: string; rune: string; drop?: boolean }

function convertWord(word: string, o: RuneOptions): string {
  const letters = [...word];
  const cells: Cell[] = letters.map((ch, k) => {
    if (isVowel(ch)) return { letter: ch, rune: vowelRune(ch, o) };
    const gi = governingVowelIndex(letters, k);
    return { letter: ch, rune: consonantRune(ch, gi === -1 ? null : letters[gi], o) };
  });
  if (o.register === "epigraphic") applyEpigraphic(cells, o);
  return cells.filter((c) => !c.drop).map((c) => c.rune).join("");
}

/**
 * Epigraphic register (one-way): vowel length unwritten; а/э written only
 * word-finally; other vowels written in the first syllable and word-finally;
 * лт/лд → 𐰡, нт/нд → 𐰧, нч → 𐰩. Consonant series are computed before any
 * vowel is dropped, so the series still carries the harmony the vowel would have.
 */
function applyEpigraphic(cells: Cell[], o: RuneOptions): void {
  const last = cells.length - 1;
  let nucleus = -1;
  for (let k = 0; k < cells.length; k++) {
    const ch = cells[k].letter;
    if (!isVowel(ch)) continue;
    const continuesLong = k > 0 && cells[k - 1].letter === ch;
    if (continuesLong) { cells[k].drop = true; continue; }  // length unwritten
    nucleus++;
    // the word-final vowel is the last vowel cell, including the second half of a long one
    let end = k; while (end + 1 <= last && cells[end + 1].letter === ch) end++;
    const wordFinal = end === last;
    if (wordFinal) continue;
    if (LOW_VOWELS.has(ch)) { cells[k].drop = true; continue; }
    if (nucleus > 0) cells[k].drop = true;
  }
  // ligatures over original adjacency
  const ENT = o.variants === "orkhon" ? RUNE.ORKHON_ENT : RUNE.YENISEI_ENT;
  const ENC = o.variants === "orkhon" ? RUNE.ORKHON_ENC : RUNE.YENISEI_ENC;
  for (let k = 0; k + 1 < cells.length; k++) {
    const a = cells[k].letter, b = cells[k + 1].letter;
    let lig: string | null = null;
    if (a === "l" && (b === "t" || b === "d")) lig = RUNE.ORKHON_ELT;
    else if (a === "n" && (b === "t" || b === "d")) lig = ENT;
    else if (a === "n" && b === "ç") lig = ENC;
    if (lig) { cells[k].rune = lig; cells[k + 1].drop = true; k++; }
  }
}

// ───────────────────────────── text conversion ─────────────────────────────

/** Convert canonical Jany-Latyn full-form text to runes. Non-JL characters pass through. */
export function toRunes(jlFull: string, opts: Partial<RuneOptions> = {}): string {
  const o: RuneOptions = { ...DEFAULT_OPTIONS, ...opts };
  const text = jlFull.normalize("NFC").toLowerCase();
  // a word is a maximal run of JL letters; hyphens, digits, punctuation pass through
  let out = text.replace(/[abçdefghiíjklmnŋoöprsştuüvyzä]+/gu, (w) => convertWord(w, o));
  if (o.separator === "two-dot") {
    // a single U+205A between two rune words replaces the run of spaces
    out = out.replace(/(\p{Script=Old_Turkic}) +(?=\p{Script=Old_Turkic})/gu, `$1${TWO_DOT}`);
  }
  return out;
}

// ───────────────────────────── reverse (plene only) ─────────────────────────────

/** Rune → JL letter for the default glyph set. 𐰆 returns "O" as a placeholder for о/у. */
const REVERSE: Record<string, string> = {
  [RUNE.ORKHON_A]: "a", [RUNE.YENISEI_A]: "a", [RUNE.YENISEI_AE]: "a", [RUNE.YENISEI_E]: "e",
  [RUNE.ORKHON_I]: "y", [RUNE.YENISEI_I]: "i", [RUNE.ORKHON_O]: "O",
  [RUNE.ORKHON_OE]: "ö", [RUNE.YENISEI_OE]: "ü",
  [RUNE.ORKHON_AB]: "b", [RUNE.ORKHON_AEB]: "b", [RUNE.YENISEI_AB]: "v",
  [RUNE.ORKHON_AG]: "g", [RUNE.ORKHON_AEG]: "g",
  [RUNE.ORKHON_AD]: "d", [RUNE.ORKHON_AED]: "d",
  [RUNE.ORKHON_EZ]: "z", [RUNE.YENISEI_EZ]: "z",
  [RUNE.ORKHON_AY]: "í", [RUNE.ORKHON_AEY]: "í",
  [RUNE.YENISEI_EC]: "j", [RUNE.YENISEI_AEY]: "j",
  [RUNE.ORKHON_AQ]: "k", [RUNE.ORKHON_IQ]: "k", [RUNE.ORKHON_OQ]: "k",
  [RUNE.ORKHON_AEK]: "k", [RUNE.ORKHON_OEK]: "k",
  [RUNE.ORKHON_AL]: "l", [RUNE.ORKHON_AEL]: "l",
  [RUNE.ORKHON_AN]: "n", [RUNE.ORKHON_AEN]: "n",
  [RUNE.ORKHON_AR]: "r", [RUNE.ORKHON_AER]: "r",
  [RUNE.ORKHON_AS]: "s", [RUNE.ORKHON_AES]: "s",
  [RUNE.ORKHON_AT]: "t", [RUNE.YENISEI_AT]: "t", [RUNE.ORKHON_AET]: "t", [RUNE.ORKHON_OT]: "t",
  [RUNE.ORKHON_EC]: "ç", [RUNE.ORKHON_IC]: "ç",
  [RUNE.ORKHON_ENG]: "ŋ", [RUNE.YENISEI_ANG]: "ŋ", [RUNE.YENISEI_AENG]: "ŋ",
  [RUNE.ORKHON_EM]: "m", [RUNE.ORKHON_EP]: "p", [RUNE.ORKHON_ESH]: "ş",
  [RUNE.YENISEI_AL]: "f", [RUNE.YENISEI_OEK]: "h",
};

/**
 * о/у resolution, deterministic and dictionary-free. The only position the
 * rules settle is a non-first syllable after а or ы, where Kyrgyz rounding
 * harmony excludes о; everywhere else the default is a positional choice
 * (measured on the corpus, see test.ts), not a certainty.
 */
export type OContext = "first" | "after-unrounded-back" | "after-rounded" | "after-front";

/** Context of an о/у at k, read from the letters to its left (used by the corpus statistics). */
export function oContext(letters: string[], k: number): OContext {
  for (let i = k - 1; i >= 0; i--) {
    const L = letters[i];
    if (!isVowel(L) && L !== "O") continue;
    if (L === "a" || L === "y") return "after-unrounded-back";
    if (L === "o" || L === "u" || L === "O") return "after-rounded";
    return "after-front";
  }
  return "first";
}

const nucleusClass = (v: string | undefined) =>
  v === undefined ? "none" : v === "a" || v === "y" ? "ay" : v === "O" ? "ou" : "front";

/**
 * The key the о/у table is indexed by, built only from what the runes show:
 * the class of the previous and next vowel nuclei (𐰆 counts as "ou"),
 * whether this 𐰆 is doubled, and whether it ends the word.
 */
function oKey(letters: string[], k: number): string {
  const nuclei: { k: number; v: string }[] = [];
  for (let i = 0; i < letters.length; i++) {
    const L = letters[i];
    if (!(isVowel(L) || L === "O")) continue;
    if (i > 0 && letters[i - 1] === L) continue;
    nuclei.push({ k: i, v: L });
  }
  const idx = nuclei.findIndex((n) => n.k === k);
  const long = letters[k + 1] === "O";
  const end = long ? k + 1 : k;
  return [
    nucleusClass(nuclei[idx - 1]?.v),
    long ? "long" : "short",
    nucleusClass(nuclei[idx + 1]?.v),
    end === letters.length - 1 ? "final" : "nonfinal",
  ].join("|");
}

export interface ReverseResult { jl: string; guessed: number }

/**
 * Runes (plene, chart vowels) → Jany-Latyn full form. The engine's JL→Cyrillic
 * stage does the rest. Every 𐰆 is resolved to о or у by O_TABLE; `guessed`
 * counts them so the UI can mark each one.
 */
export function fromRunes(runes: string): ReverseResult {
  let guessed = 0;
  const jl = runes.replaceAll(TWO_DOT, " ").replace(/\p{Script=Old_Turkic}+/gu, (w) => {
    const orig = [...w].map((r) => REVERSE[r] ?? r);
    const out = [...orig];
    for (let k = 0; k < out.length; k++) {
      if (orig[k] !== "O") continue;
      if (k > 0 && orig[k - 1] === "O") { out[k] = out[k - 1]; continue; } // long vowel
      out[k] = O_TABLE[oKey(orig, k)] ?? "o";
      guessed++;
    }
    return out.join("");
  });
  return { jl, guessed };
}
